﻿using ContactApp.Controllers;
using ContactApp.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Mvc;
namespace ContactApp.Tests.Controllers
{
    [TestClass]
    public class ContactControllerTest
    {
        [TestMethod]
        public void Index()
        {
            ContactsController controller = new ContactsController();

            // Act
            ViewResult result = controller.Index() as ViewResult;

            // Assert
            Assert.IsNotNull(result);

        }

        [TestMethod]
        public void Create()
        {
            ContactsController controller = new ContactsController();

            Contact oContact = new Contact();
            oContact.FirstName = "First Test";
            oContact.LastName = "Last Test";
            oContact.Email = "test@test.com";
            oContact.PhoneNumber = "2352325989";
            oContact.Status = true;

            // Act
            ActionResult result = controller.Create(oContact) as ActionResult;

            // Assert
            Assert.IsNotNull(result);

        }

        [TestMethod]
        public void Update()
        {
            ContactsController controller = new ContactsController();
            ContactController oCC = new ContactController();
            Contact oContact = new Contact();
            int id = 2; //Hardcoded id
            oContact = oCC.Get(id.ToString());
            oContact.LastName = "Update Last Name";
            // Act
            ActionResult result = controller.Edit(oContact) as ActionResult;

            // Assert
            Assert.IsNotNull(result);

        }

        [TestMethod]
        public void Delete()
        {
            ContactsController controller = new ContactsController();
            ContactController oCC = new ContactController();
            Contact oContact = new Contact();
            int id = 9; //Hardcoded id you need to make sure you have that id in database

            // Act
            ActionResult result = controller.DeleteConfirmed(id) as ActionResult;

            // Assert
            Assert.IsNotNull(result);

        }
    }
}
