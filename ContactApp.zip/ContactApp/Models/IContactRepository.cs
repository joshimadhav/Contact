﻿using System.Collections.Generic;

namespace ContactApp.Models
{
    public interface IContactRepository
    {
        IEnumerable<Contact> SelectAll();
        Contact SelectByID(string id);
        void Insert(Contact obj);
        void Update(Contact obj);
        void Delete(string id);
        void Save();
    }
}
