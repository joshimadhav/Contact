﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace ContactApp.Models
{
    public class ContactRepository : IContactRepository
    {
        private ContactEDM db = null;

        public ContactRepository()
        {
            this.db = new ContactEDM();
        }

        public ContactRepository(ContactEDM db)
        {
            this.db = db;
        }

        public IEnumerable<Contact> SelectAll()
        {
            return db.Contacts.ToList();
        }

        public Contact SelectByID(string id)
        {
            if (!string.IsNullOrEmpty(id))
                return db.Contacts.Find(Convert.ToInt32(id));
            else
                return null;
        }

        public void Insert(Contact obj)
        {
            db.Contacts.Add(obj);
        }

        public void Update(Contact obj)
        {
            db.Entry(obj).State = EntityState.Modified;
        }

        public void Delete(string id)
        {
            Contact existing = db.Contacts.Find(Convert.ToInt32(id));
            db.Contacts.Remove(existing);
        }

        public void Save()
        {
            db.SaveChanges();
        }
    }
}