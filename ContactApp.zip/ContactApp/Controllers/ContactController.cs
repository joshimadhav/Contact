﻿using ContactApp.Models;
using System.Collections.Generic;
using System.Web.Http;

namespace ContactApp.Controllers
{


    public class ContactController : ApiController
    {
        private IContactRepository repository = null;
        public ContactController()
        {
            this.repository = new ContactRepository();
        }
        public ContactController(IContactRepository repository)
        {
            this.repository = repository;
        }

        // GET api/values
        public IEnumerable<Contact> Get()
        {
            List<Contact> model = (List<Contact>)repository.SelectAll();
            return model;
        }

        // GET api/values/5
        public Contact Get(string id)
        {
            Contact existing = repository.SelectByID(id.ToString());
            return existing;
        }

        // POST api/values
        public void Post([FromBody]Contact obj)
        {
            repository.Insert(obj);
            repository.Save();
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]Contact obj)
        {
            repository.Update(obj);
            repository.Save();
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
            repository.Delete(id.ToString());
            repository.Save();
        }
    }
}
