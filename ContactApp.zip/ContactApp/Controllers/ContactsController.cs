﻿using ContactApp.Models;
using System.Net;
using System.Web.Mvc;

namespace ContactApp.Controllers
{
    public class ContactsController : Controller
    {

        ContactController oCC = new ContactController();

        public ActionResult Index()
        {
            return View(oCC.Get());
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Contact obj)
        {
            if (ModelState.IsValid)
            {
                oCC.Post(obj);
                return RedirectToAction("Index");
            }

            return View();
        }

        public ActionResult Edit(string id)
        {
            Contact existing = oCC.Get(id);
            return View(existing);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ContactId,FirstName,LastName,Email,PhoneNumber,Status")] Contact contact)
        {
            if (ModelState.IsValid)
            {
                oCC.Put(0, contact);
                return RedirectToAction("Index");
            }
            return View(contact);
        }

        // GET: Contacts/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Contact contact = oCC.Get(id.ToString());
            if (contact == null)
            {
                return HttpNotFound();
            }
            return View(contact);
        }

        //// GET: Contacts/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Contact contact = oCC.Get(id.ToString());
            if (contact == null)
            {
                return HttpNotFound();
            }
            return View(contact);
        }

        // POST: Contacts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            oCC.Delete(id);
            return RedirectToAction("Index");
        }

    }
}
