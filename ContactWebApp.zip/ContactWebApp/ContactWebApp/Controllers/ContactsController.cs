﻿using ContactWebApp.Models;
using System.Collections.Generic;
using System.Net;
using System.Web.Mvc;

namespace ContactWebApp.Controllers
{
    public class ContactsController : Controller
    {
        private IContactRepository repository = null;
        public ContactsController()
        {
            this.repository = new ContactRepository();
        }
        public ContactsController(IContactRepository repository)
        {
            this.repository = repository;
        }


        public ActionResult Index()
        {
            List<Contact> model = (List<Contact>)repository.SelectAll();
            return View(model);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Contact obj)
        {
            if (ModelState.IsValid)
            {
                repository.Insert(obj);
                repository.Save();
                return RedirectToAction("Index");
            }

            return View();
        }

        public ActionResult Edit(string id)
        {
            Contact existing = repository.SelectByID(id);
            return View(existing);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ContactId,FirstName,LastName,Email,PhoneNumber,Status")] Contact contact)
        {
            if (ModelState.IsValid)
            {
                repository.Update(contact);
                repository.Save();
                return RedirectToAction("Index");
            }
            return View(contact);
        }

        // GET: Contacts/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Contact contact = repository.SelectByID(id.ToString());
            if (contact == null)
            {
                return HttpNotFound();
            }
            return View(contact);
        }

        //// GET: Contacts/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Contact contact = repository.SelectByID(id.ToString());
            if (contact == null)
            {
                return HttpNotFound();
            }
            return View(contact);
        }

        // POST: Contacts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            repository.Delete(id.ToString());
            repository.Save();
            return RedirectToAction("Index");
        }

    }
}
